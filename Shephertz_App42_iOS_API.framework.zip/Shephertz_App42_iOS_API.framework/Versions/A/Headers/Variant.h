//
//  Variant.h
//  PAE_iOS_SDK
//
//  Created by Rajeev Ranjan on 17/10/13.
//  Copyright (c) 2013 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Variant : NSObject

@property(nonatomic,retain) NSString *name;
@property(nonatomic,retain) NSString *profile;

@end
