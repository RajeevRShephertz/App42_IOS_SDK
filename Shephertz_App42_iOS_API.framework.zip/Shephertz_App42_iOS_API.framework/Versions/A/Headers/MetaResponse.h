//
//  MetaResponse.h
//  PAE_iOS_SDK
//
//  Created by Rajeev Ranjan on 06/02/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaResponse : NSObject

@property(nonatomic,retain) NSArray *jsonDocArray;
@end
